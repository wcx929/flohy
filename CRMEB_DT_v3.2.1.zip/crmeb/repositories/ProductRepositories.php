<?php
namespace crmeb\repositories;

use app\models\store\StoreOrder;
use app\models\user\User;
use app\models\user\UserAddress;
use app\models\user\WechatUser;
use crmeb\services\SystemConfigService;
use crmeb\services\WechatTemplateService;

/**
 * Class ProductRepositories
 * @package crmeb\repositories
 */
class ProductRepositories
{
    
}