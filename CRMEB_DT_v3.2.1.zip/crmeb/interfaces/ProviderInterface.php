<?php


namespace crmeb\interfaces;


interface ProviderInterface
{
    public function register($config);
}

