<?php

namespace crmeb\command;

use Channel\Server;
use crmeb\services\WorkermanService;
use think\console\Command;
use think\console\Input;
use think\console\input\Argument;
use think\console\input\Option;
use think\console\Output;
use think\facade\Log;
use Workerman\Worker;

class Queue extends Command
{

    protected function configure()
    {

    }

    protected function execute(Input $input, Output $output)
    {

    }
}