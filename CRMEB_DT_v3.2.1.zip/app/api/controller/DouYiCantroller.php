<?php

namespace app\api\controller;

/**
 * 抖音小程序
 * Class DouYiCantroller
 * @package app\api\controller
 */
class DouYiCantroller
{

    public function auth()
    {

    }

}