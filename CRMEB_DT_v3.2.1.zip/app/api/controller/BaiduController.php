<?php

namespace app\api\controller;

/**
 * 百度小程序
 * Class BaiduController
 * @package app\api\controller
 */
class BaiduController
{

    public function auth()
    {

    }

}