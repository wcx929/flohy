<?php

namespace app\models\article;

use crmeb\traits\ModelTrait;
use crmeb\basic\BaseModel;


/**
 * 文章详情
 * Class ArticleCategory
 * @package app\models\article
 */
class ArticleContent extends BaseModel
{
    use ModelTrait;
}